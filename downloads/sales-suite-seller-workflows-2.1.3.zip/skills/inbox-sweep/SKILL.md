---
name: inbox-sweep
description: "Triage authorized customer mail into account context, priority, and draft follow-through. Use when a seller, sales leader, or demo operator asks for inbox sweep, related CRM analysis, or its governed next action."
license: MIT
---

# Inbox Sweep

## Outcome

Triage authorized customer mail into account context, priority, and draft follow-through.

## Workflow

1. Resolve one exact account, opportunity, person, activity, meeting, or authorized portfolio scope before deep retrieval.
2. Confirm the signed-in user, provider, environment, intended host, and effect boundary.
3. Ground dynamic CRM fields, stages, relationships, and labels before relying on them.
4. Gather only the minimum current evidence from Dynamics 365 and authorized Microsoft 365 context; preserve provider, record type, record ID, observation time, and canonical URL.
5. Route through the suite workflow `inbox-sweep` and these existing delegates when available: `workiq`.
6. Surface missing, denied, stale, ambiguous, or contradictory evidence instead of filling gaps.
7. Return a review-required draft. Never send, save, schedule, commit, or change forecast state.

## Conversational scope

Sellers do not need to know a record GUID. Accept an account or opportunity name,
business description, or prior confirmed selection. Within the authorized discovery
scope, show likely matches using account, opportunity, owner, and stage where
available. Ask the seller to choose when ambiguous; never treat the most probable
match as confirmed. Resolve IDs behind the scenes before deeper retrieval. Do not
repeat discovery after the seller has confirmed the record unless evidence conflicts.
For notes-only tasks, use the supplied context without searching CRM or requiring an ID.

## Execution and evidence coverage

- Identify this workflow in the response. Claim a delegate or tool ran only when host activity confirms invocation; otherwise mark it unavailable or unverified.
- Check delegate availability once. Missing delegates are optional composition gaps, not permission to invent their results or recursively invoke this workflow.
- If a Sales API fails, report the failed capability and permission/error. Never request broad admin rights or retry the same denied call repeatedly.
- Use direct CRM reads only when authorized for the same signed-in user, provider, environment, account, and effect scope. Disclose that fallback and which Sales summaries or scores were not obtained; otherwise stop at the blocker.
- Maintain a compact evidence-coverage ledger: checked sources and time window, unavailable sources, and sources not checked. An empty or denied query is not proof that evidence does not exist.
- Distinguish status from sales stage, deal-team membership from ownership, null from zero, and record modification from a human update. Use actual provider field definitions.
- Reuse cited evidence within the task unless freshness or conflicting evidence requires a targeted reread. Never silently expand retrieval to Microsoft 365 or other accounts.

## Host

- Primary host: `cowork`.
- D365 execution pattern: `supervised-multistep`.
- Use Copilot Cowork for supervised multi-step work with visible checkpoints.
- If the primary host or a required connector is unavailable, return a paste-ready checklist or draft and name the missing dependency.

## Output

Lead with the seller's decision, not package mechanics. Use a concise native Markdown layout:

1. **Bottom line:** one or two conversational sentences explaining what matters and the next useful move, with partial coverage called out before conclusions.
2. **Evidence:** a compact table of finding, source/date, and meaning when comparison helps; otherwise use a few short cited statements. Attach working record citations to facts. Separate facts from interpretation.
3. **What needs attention:** the most important unknowns and coverage limits. Do not present unverified risks as facts.
4. **Recommended next step:** one evidence-backed action, proposed owner, prerequisite, and reason. Label owner and dates as proposals unless verified.
5. **V-team handoff:** only the relevant contributors, what each needs to do, the dependency order, and the decision or evidence that lets work move forward. Follow the orchestration rules below.
6. **Continue with:** at most two optional, paste-ready follow-on requests for available workflows. Pass the same exact scope and a short cited handoff; do not automatically invoke, broaden access, or execute actions.
7. **Run details:** workflow used, actual tools/delegates or disclosed fallback, human-review state, and effect receipt. Distinguish reported effects from independently verified effects.

### Human, visually scannable responses

Use meaningful Markdown headings, whitespace, bold lead-ins, a short blockquote
for the next best action, and small tables only for genuinely tabular information.
Keep the bottom line and next best action together on the first screen; for example:

**Bottom line:** [What the evidence means for the seller, with any material limitation.]

> **Next best action:** [One action] | **Owner:** [confirmed or proposed].
> **Why now:** [Evidence-backed reason]. **Ready when:** [Actual prerequisite or "none identified"].

Then show the supporting evidence and any useful team handoff. Do not repeat the
same recommendation in multiple sections; the callout can satisfy Recommended
next step. Adapt to the requested task instead of forcing every heading into a
simple answer. For meeting follow-up, keep recap, agreed actions, open decisions,
and the review-only email distinct. Keep synthetic rehearsal labels prominent.
When a task has a gated path and separate work that can proceed in parallel,
make that distinction visible with short sections such as **Customer-data gate**
and **Can proceed in parallel**. Number only genuinely sequential gate steps
and label each Confirmed, Waiting, or Blocked in text. List parallel actions
with owners and source-backed due dates. Do not imply that parallel work is
unblocked if its own data, access, or approval prerequisites are unknown; state
the limitation. Prefer this over a dense table when it clarifies dependencies,
and do not repeat actions already stated in the next-action callout. For simple
tasks without parallel work or a gated sequence, keep the response short and
omit these sections.
Use short, natural sentences and seller-facing language: account, opportunity,
customer need, decision, and next step. Call business capabilities agents or
workflows, not skills. Avoid raw bullet dumps, decorative emoji, wall-of-text
receipts, and blanket phrases such as "no commitments" when actions were agreed.
Use text status labels such as Confirmed, Proposed, and Needs confirmation; never
rely on color or icons alone. Use standard Markdown table header separators and
short cells, not pseudo-tables, HTML cards, or unsupported widgets. Keep essential
coverage and effect limits visible; put technical diagnostics last.

### V-team orchestration

Make the next best action the smallest evidence-backed move toward the customer's
outcome, not a generic instruction to run another workflow. If blocked, make the
next move the specific missing decision, permission, or evidence request. Do not
invent urgency, deadlines, dependencies, customer agreement, or promises. Respect
the task's effect limits in the recommended action: if sending or saving is
prohibited, recommend review or approval of the in-chat draft, not that the user
send it. A logical next step is not itself authorization.

Use a compact **Who / Next move / Handoff or decision gate** table when multiple
contributors are genuinely needed; for one owner, use one sentence instead.
Use verified named owners where available. Otherwise propose the appropriate
role (AE/ATS for account alignment, SSP/SE for solution validation, CSAM/CSU for
adoption and delivery), mark it Proposed, and ask for ownership confirmation only
when needed to proceed. Do not recruit every role by default or substitute
Microsoft role labels for the customer's actual role. Opportunity ownership does
not establish ownership of every action.

Separate agreed actions from proposed coordination. A proposed handoff must carry
the confirmed account/opportunity or notes-only scope, a minimum cited evidence
summary, the requested outcome, the recipient role, and the completion gate.
Do not repeat the next-best-action callout in the handoff table: reserve the callout
for the immediate action and the table for distinct supporting owners, dependencies,
or gates. For customer-data or security gates, distinguish reviewer identified,
review completed, and data-use decision/conditions documented. Identifying a
reviewer does not mean the review passed or authorize data use; do not advance to a
later stage until its actual gate is confirmed.
Suggest an available next workflow only when it helps that handoff; if availability
is unknown, mark it unverified and offer a manual handoff rather than claiming it
can run. Never claim a colleague was notified or an assignment, meeting, or CRM
update happened merely because it appears in this plan. Preparing a handoff does
not authorize sending, scheduling, assigning, writing, or automatic delegation.

Show human labels rather than API names or raw identifiers. Cite each material CRM fact with a clickable source when the provider supplies a canonical URL. If it supplies only a verified record GUID, construct a standard Dynamics record URL only when the exact organization base URL and logical table name are independently present in evidence retrieved during this same workflow run; prior turns, email-derived links, memory, or a URL that merely opens successfully do not verify the current connection's organization. Use the provider-documented record form `https://<verified-host>/main.aspx?etn=<logical-table>&id=<record-guid>&pagetype=entityrecord` and label it **constructed link**, not a provider-returned URL. Put only that verified HTTP(S) record URL in the citation's hyperlink target. Never hyperlink an annotation name, field name, OData metadata label, `mailto:` value, or raw identifier. Never guess the organization, entity set, or record ID. If a safe URL cannot be constructed, show the record ID as a trace reference and say the citation is not clickable.

Before returning, reconcile the headline with every cited date and evidence-coverage limit. Use source-specific freshness labels (for example, "Forecast Comments last updated" versus "activity rollup timestamp"); never call one the account's or deal's overall last update. Do not assign meaning such as "recalculated" or "system-stamped" to a timestamp unless its semantics are verified. Scope each negative finding to the sources actually queried; an unchecked source cannot support an absence claim. If timestamps conflict or a rollup lacks a retrieved underlying record, surface that distinction in the headline and gaps instead of smoothing it over. If only one dated source category was checked, state "latest [source] retrieved" rather than "latest update," "latest real update," or "latest engagement."

Use charts only when the host supports them and the retrieved dated series supports the visual; otherwise use a small table. Never invent scores, trends, buttons, or interactive controls. For blocked runs, give the blocker and smallest safe next step rather than an empty report. Keep API errors and raw field names in Run details, not the headline.

## Boundaries

- Write policy: `draft-only`.
- Write gate: `none`.
- Definition state: `definition-ready`; qualification: `L0-mapped`.
- Never widen customer scope, invent records, silently switch providers, or treat a mapped capability as host-qualified.

## Consolidation trial boundary

Intended audience: Sales rep, Sales leader, and account team. This is an unqualified consolidation candidate, not proof of host support. The effect policy above remains authoritative. A rehearsal, discovery test, or explicit no-effect request must never send, save, schedule, assign, write, deploy, authenticate, create a watch, or change permissions. Return an in-chat preview or missing-input question instead. Use fictional supplied notes for tests; do not retrieve customer data unless the seller separately authorizes exact scope. Proposed handoffs do not contact colleagues.

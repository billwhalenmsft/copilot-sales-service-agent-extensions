---
name: first-time-fix-risk
description: "Surface first-time-fix risks from skills, parts, history, diagnostics, and access constraints. Use when a seller, manager, account team, service team, or operator asks about work orders, technicians, assets, parts, safety, dispatch, or field-to-sales context."
license: MIT
---

# First Time Fix Risk

## Outcome

Surface first-time-fix risks from skills, parts, history, diagnostics, and access constraints.

## Trigger

Use this capability only when the request matches `first-time-fix-risk` and its `field-service` outcome. Resolve an exact account, opportunity, case, work order, meeting, person, provider, deployment, or explicitly authorized portfolio scope before retrieval.

## Host And Providers

- Supported surfaces: `sales-agent`, `cowork`, `service-agent`.
- Intended Microsoft primary route: `sales-agent`.
- Required providers: `dataverse`.
- D365 reference pattern: `evidence-read`.

## Inputs

- Signed-in user and exact authorized scope.
- Provider and environment identity.
- Workflow-specific current evidence, observation time, freshness policy, and canonical source links.
- Intended audience, review state, and effect boundary.
- Any customer-owned rule, checklist, metric, corpus, authority, or approval prerequisite named by this capability.

## Evidence Contract

Preserve provider, entity kind, record ID, observation time, applicable period, freshness, confidence, excerpt, canonical URL, authority, contradiction, and permission state. Never merge provider-owned truth silently or fill an absent customer rule with a generic one.

## Workflow

1. Resolve one exact authorized scope and signed-in identity.
2. Ground provider entities, fields, relationships, and record grammar.
3. Read only the minimum current evidence and preserve provider-owned citations.
4. Apply workflow-specific authority and freshness rules.
5. Return evidence, gaps, confidence, and a zero-effect receipt.

## Output

Return the requested outcome, exact scope, evidence and citations, gaps and blockers, proposed next action, human-review state, provider/effect state, qualification level, and receipt. Show human labels rather than raw API names or identifiers.

## Effect Boundary

Read and analyze only. Return a zero-effect receipt and never imply that source data changed.

## Fallback

If a required host, permission, schema, or provider (dataverse) is unavailable, return a paste-ready checklist or draft, name the missing dependency, preserve known evidence, and perform no business effect.

## Acceptance

- Exact authorized scope and signed-in identity are visible.
- Every consequential claim resolves to a provider-owned citation or is labeled unknown.
- Missing, stale, denied, ambiguous, contradictory, and malformed inputs fail closed.
- The intended Microsoft host renders the complete result without native fallback masquerading as extension output.
- Telemetry attributes execution and the effect receipt matches the declared write policy.
- Before-and-after source comparison proves zero unexpected writes.

## Maturity

- Portfolio: additive expansion.
- Definition state: `contract-required`.
- Qualification: `L0-cataloged` unless a separate immutable receipt names this exact workflow and host.
- Priority: `P1`.
- Never present catalog inclusion, local generation, package validity, another workflow's proof, or provider similarity as host qualification.

## Candidate conversational and presentation guidance

Accept a natural-language account or opportunity description; show plausible matches within authorized discovery scope and ask for confirmation when ambiguous. Resolve IDs behind the scenes before deep retrieval. Notes-only tasks require no CRM search or GUID. Claim workflow execution only when host activity confirms invocation. Do not treat packaged helpers as available until verified. Optional source coverage never authorizes a broader query. Providers listed above are supported possibilities, not permission to connect every provider; use only those required and explicitly authorized for this task.

Lead with the seller's decision, not package mechanics. Use a concise native Markdown layout:

1. **Bottom line:** one or two conversational sentences explaining what matters and the next useful move, with partial coverage called out before conclusions.
2. **Evidence:** a compact table of finding, source/date, and meaning when comparison helps; otherwise use a few short cited statements. Attach working record citations to facts. Separate facts from interpretation.
3. **What needs attention:** the most important unknowns and coverage limits. Do not present unverified risks as facts.
4. **Recommended next step:** one evidence-backed action, proposed owner, prerequisite, and reason. Label owner and dates as proposals unless verified.
5. **V-team handoff:** only the relevant contributors, what each needs to do, the dependency order, and the decision or evidence that lets work move forward. Follow the orchestration rules below.
6. **Continue with:** at most two optional, paste-ready follow-on requests for available workflows. Pass the same exact scope and a short cited handoff; do not automatically invoke, broaden access, or execute actions.
7. **Run details:** workflow used, actual tools/delegates or disclosed fallback, human-review state, and effect receipt. Distinguish reported effects from independently verified effects.

### Human, visually scannable responses

Use meaningful Markdown headings, whitespace, bold lead-ins, a short blockquote
for the next best action, and small tables only for genuinely tabular information.
Keep the bottom line and next best action together on the first screen; for example:

**Bottom line:** [What the evidence means for the seller, with any material limitation.]

> **Next best action:** [One action] | **Owner:** [confirmed or proposed].
> **Why now:** [Evidence-backed reason]. **Ready when:** [Actual prerequisite or "none identified"].

Then show the supporting evidence and any useful team handoff. Do not repeat the
same recommendation in multiple sections; the callout can satisfy Recommended
next step. Adapt to the requested task instead of forcing every heading into a
simple answer. For meeting follow-up, keep recap, agreed actions, open decisions,
and the review-only email distinct. Keep synthetic rehearsal labels prominent.
When a task has a gated path and separate work that can proceed in parallel,
make that distinction visible with short sections such as **Customer-data gate**
and **Can proceed in parallel**. Number only genuinely sequential gate steps
and label each Confirmed, Waiting, or Blocked in text. List parallel actions
with owners and source-backed due dates. Do not imply that parallel work is
unblocked if its own data, access, or approval prerequisites are unknown; state
the limitation. Prefer this over a dense table when it clarifies dependencies,
and do not repeat actions already stated in the next-action callout. For simple
tasks without parallel work or a gated sequence, keep the response short and
omit these sections.
Use short, natural sentences and seller-facing language: account, opportunity,
customer need, decision, and next step. Call business capabilities agents or
workflows, not skills. Avoid raw bullet dumps, decorative emoji, wall-of-text
receipts, and blanket phrases such as "no commitments" when actions were agreed.
Use text status labels such as Confirmed, Proposed, and Needs confirmation; never
rely on color or icons alone. Use standard Markdown table header separators and
short cells, not pseudo-tables, HTML cards, or unsupported widgets. Keep essential
coverage and effect limits visible; put technical diagnostics last.

### V-team orchestration

Make the next best action the smallest evidence-backed move toward the customer's
outcome, not a generic instruction to run another workflow. If blocked, make the
next move the specific missing decision, permission, or evidence request. Do not
invent urgency, deadlines, dependencies, customer agreement, or promises. Respect
the task's effect limits in the recommended action: if sending or saving is
prohibited, recommend review or approval of the in-chat draft, not that the user
send it. A logical next step is not itself authorization.

Use a compact **Who / Next move / Handoff or decision gate** table when multiple
contributors are genuinely needed; for one owner, use one sentence instead.
Use verified named owners where available. Otherwise propose the appropriate
role (AE/ATS for account alignment, SSP/SE for solution validation, CSAM/CSU for
adoption and delivery), mark it Proposed, and ask for ownership confirmation only
when needed to proceed. Do not recruit every role by default or substitute
Microsoft role labels for the customer's actual role. Opportunity ownership does
not establish ownership of every action.

Separate agreed actions from proposed coordination. A proposed handoff must carry
the confirmed account/opportunity or notes-only scope, a minimum cited evidence
summary, the requested outcome, the recipient role, and the completion gate.
Do not repeat the next-best-action callout in the handoff table: reserve the callout
for the immediate action and the table for distinct supporting owners, dependencies,
or gates. For customer-data or security gates, distinguish reviewer identified,
review completed, and data-use decision/conditions documented. Identifying a
reviewer does not mean the review passed or authorize data use; do not advance to a
later stage until its actual gate is confirmed.
Suggest an available next workflow only when it helps that handoff; if availability
is unknown, mark it unverified and offer a manual handoff rather than claiming it
can run. Never claim a colleague was notified or an assignment, meeting, or CRM
update happened merely because it appears in this plan. Preparing a handoff does
not authorize sending, scheduling, assigning, writing, or automatic delegation.

Show human labels rather than API names or raw identifiers. Cite each material CRM fact with a clickable source when the provider supplies a canonical URL. If it supplies only a verified record GUID, construct a standard Dynamics record URL only when the exact organization base URL and logical table name are independently present in evidence retrieved during this same workflow run; prior turns, email-derived links, memory, or a URL that merely opens successfully do not verify the current connection's organization. Use the provider-documented record form `https://<verified-host>/main.aspx?etn=<logical-table>&id=<record-guid>&pagetype=entityrecord` and label it **constructed link**, not a provider-returned URL. Put only that verified HTTP(S) record URL in the citation's hyperlink target. Never hyperlink an annotation name, field name, OData metadata label, `mailto:` value, or raw identifier. Never guess the organization, entity set, or record ID. If a safe URL cannot be constructed, show the record ID as a trace reference and say the citation is not clickable.

Before returning, reconcile the headline with every cited date and evidence-coverage limit. Use source-specific freshness labels (for example, "Forecast Comments last updated" versus "activity rollup timestamp"); never call one the account's or deal's overall last update. Do not assign meaning such as "recalculated" or "system-stamped" to a timestamp unless its semantics are verified. Scope each negative finding to the sources actually queried; an unchecked source cannot support an absence claim. If timestamps conflict or a rollup lacks a retrieved underlying record, surface that distinction in the headline and gaps instead of smoothing it over. If only one dated source category was checked, state "latest [source] retrieved" rather than "latest update," "latest real update," or "latest engagement."

Use charts only when the host supports them and the retrieved dated series supports the visual; otherwise use a small table. Never invent scores, trends, buttons, or interactive controls. For blocked runs, give the blocker and smallest safe next step rather than an empty report. Keep API errors and raw field names in Run details, not the headline.


## Consolidation trial boundary

Intended audience: Optional service or field specialist supporting the account team. This is an unqualified consolidation candidate, not proof of host support. The effect policy above remains authoritative. A rehearsal, discovery test, or explicit no-effect request must never send, save, schedule, assign, write, deploy, authenticate, create a watch, or change permissions. Return an in-chat preview or missing-input question instead. Use fictional supplied notes for tests; do not retrieve customer data unless the seller separately authorizes exact scope. Proposed handoffs do not contact colleagues.
